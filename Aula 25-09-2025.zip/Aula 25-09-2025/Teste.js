let x = 23;
typeof x;
let c = String(x);
typeof c;
let y = Number("12.5") // o mesmo que parseFloat()
let z = Number("30"); // o mesmo que parseInt()
typeof y; // retorna o tipo number
typeof z; // retorna o tipo number

let data_hora = new Date();
let hora = data_hora.getHours();
let previsao_tempo = "chuvoso";
if (hora < 12 && hora >= 5)
{
    alert("Bom dia!");
    if (previsao_tempo == "chuvoso")
    {
        alert("Está chovendo, leve o guarda-chuva.");
    }
}
else if (hora > 12 && hora < 18)
{
    alert("Boa tarde!");
}
else if (hora >= 19 && hora < 0)
{
    alert("Boa noite!");
}
else if (hora > 0 && hora < 5)
{
    alert("Boa madrugada! VAI DORMIR PÔ!");
}

let f = 10;
let g = 20;
(f > g)? alert("Sim") : alert("Não");
let h = (f < g)? "Sim": "Não";
console.log(h);

switch (dia_semana) {
    case 0: alert("Domingão do faustão!!!");
    break;
    case 5: alert("Sextou porraaaaa!!!");
    break;
    case 6: alert("SABADÃO UHUUUUU!!!");
    break;
    default: alert("Semana longa acaba logooooooo pelo amor de deeeeeus!!!");
}