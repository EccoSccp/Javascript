function calcularIR() {
    const salario = parseFloat(document.getElementById("salario").value);
    const nome = document.getElementById("nome").value;
    const registro = document.getElementById("registro").value;
    let imposto = 0;

    if (salario < 1434) {
        imposto = 0;
    }
    else if (salario >= 1434 && salario < 2150) {
        imposto = salario * 0.075;
    }
    else if (salario >= 2150 && salario < 2866) {
        imposto = salario * 0.15;
    }
    else if (salario >= 2866 && salario < 3582) {
        imposto = salario * 0.225;
    } 
    else {
        imposto = salario * 0.275;
    }

    document.getElementById("imposto").value = imposto.toFixed(2);
}