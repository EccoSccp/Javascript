 const valor = parseFloat(prompt("Digite o quanto você gastou: "));
const parcelas = parseInt(prompt("Digite quantas parcelas você gostaria de pagar: "));
let juros = 0;

switch(parcelas) {
    case 1:
        juros = 0;
        break;

    case 2:
        juros = 3;
        break;

    case 4:
        juros = 7;
        break;

    default:
        alert("Número de parcelas inválido. Use 1, 2 ou 4.");
        throw new Error("Parcelas inválidas");
}
let valor_total = valor * (1 + juros / 100);
let valor_parcela = valor_total / parcelas;
alert("Total com juros: R$" + valor_total.toFixed(2) + "\n" + parcelas + "x de R$" + valor_parcela.toFixed(2) + "(Juros: " + juros + "%");