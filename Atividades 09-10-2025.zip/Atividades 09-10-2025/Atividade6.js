document.addEventListener('DOMContentLoaded', function() {
    let preco = parseFloat(document.getElementById('preco').value);
    let condicao = parseInt(document.getElementById('condicao').value);
    let valor_original = document.getElementById('valor_original');
    let valor_final = document.getElementById('valor_final');

    if (isNaN(preco) || preco <= 0) {
        alert("Digite um valor que seja válido para o produto.");
        valor_original.value = "";
        valor_final.value = "";
    }

    let valor_calculado;

    switch(condicao) {
        case 1:
            valor_calculado = preco * 0.90;
            break;
        
        case 2:
            valor_calculado = preco * 0.95;
            break;
        
        case 3:
            valor_calculado = preco * 1.10;
            break;

        default:
            alert("Selecione uma condição de pagamento válido.");
            return;
      }

       valor_original.value = `R$ ${preco.toFixed(2)} `;
       valor_final.value = `R$ ${valor_calculado.toFixed(2)}`;

});