function calcular(operacao) {
    const num1 = parseFloat(document.getElementById("num1").value);
    const num2 = parseFloat(document.getElementById("num2").value);
    let resultado = 0;
    
    if (isNaN(num1) || isNaN(num2)) {
        alert("Por favor, insira números válidos.");
        return;
    }

    switch (operacao) {
        case 'somar':
            resultado = num1 + num2;
            break;

        case 'subtrair':
            resultado = num1 - num2;
            break;

        case 'multiplicar':
            resultado = num1 * num2;
            break;

        case 'dividir':
            if (num2 === 0) {
                alert("Não é possível dividir números por zero.");
                return;
            }
            resultado = num1 / num2;
            break;

        default:
            alert("Esta operação não é permitida.");
            return;
    }

    document.getElementById("resultado").value = resultado;
}