function verificat() {
    let x = parseInt(document.getElementById('entrada').value);
    
    if (isNaN(x)) {
        document.getElementById('saida').value = "Digite um número válido.";
    }
    else if(x % 2 === 0) {
        document.getElementById('saida').value = "O número é par.";
    }
    else {
        document.getElementById('saida').value = "O número é ímpar."
    }
}