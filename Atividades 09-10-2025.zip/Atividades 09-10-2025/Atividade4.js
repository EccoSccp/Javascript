document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('calcular').addEventListener('click', function() {
        const base = parseFloat(document.getElementById('base').value);
        const altura = parseFloat(document.getElementById('altura').value);
        let resultado = document.getElementById('resultado').value;

        if (isNaN(base) || isNaN(altura) || base <= 0 || altura <= 0) {
            resultado.value = "Digite valores positivos válidos para abase e a altura.";
            return;
        }

        let area = base * altura;
        resultado.value = "Área do retângulo: " + area;

    })
});