let n = Math.round(Math.random() * 100);
let tentativas = 0;

function verificar_chute() {
    const input = document.getElementById('chute');
    const mensagem = document.getElementById('mensagem');
    const chute = parseInt(input.value);

    if (isNaN(chute) || chute < 0 || chute > 100) {
        mensagem.textContent = "Por favor, digite um número válido entre 0 e 100.";
        mensagem.style.color = "#ff4444";
        return;
    }

    tentativas++;

    if (chute < n) {
        mensagem.textContent = "Tente um número maior!";
        mensagem.style.color = "#3333cc";
    }
    else if (chute > n) {
        mensagem.textContent = "Tente um número menor!";
        mensagem.style.color = "#cc3333";
    }
    else {
        mensagem.innerHTML = `Parabéns, você acertou o número <strong>${n}</strong> em <strong>${tentativas}</strong> tentativas. <br><br> Deseja jogar novamente?`
        mensagem.style.color = "#2e7d;"

        mensagem.innerHTML += `<br><br><button onclick="reiniciar_jogo()" class="reiniciar"> Jogar novamente?</button>`;
    }

    input.value = '';
    input.focus();
}

function reiniciar_jogo() {
    numeroSecreto = Math.round(Math.random() * 100);
    tentativas = 0;
    document.getElementById('mensagem').textContent = '';
    document.getElementById('chute').value = '';
    document.getElementById('chute').focus();
}