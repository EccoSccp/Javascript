document.addEventListener('DOMContentLoaded', function () {
    document.getElementById('formulario').addEventListener('submit', function(event) {
        event.preventDefault();

        let x = parseInt(document.getElementById('numero1').value);
        let y = parseInt(document.getElementById('numero2').value);
        let z = document.getElementById('resultado');

        if(isNaN(x) || isNaN(y)) {
            z.value = "Por favor, preencha os dois números.";
        }
        else if  (x > y) {
            z.value = `O maior número é ${x}.`;
        }
        else if ( y > x) {
            z.value = `O maio número é ${y}`;
        }
        else {
            z.value = "Os números são iguais.";
        }
    })
})