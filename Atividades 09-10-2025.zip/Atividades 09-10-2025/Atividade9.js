function calcularSoma() {
    const n = parseInt(document.getElementById("numero").value);

    if (isNaN(n) || n < 1) {
        alert("Informe um número inteiro e positivo.");
        return;
    }

    const soma = n * (n + 1) / 2;

    document.getElementById("resultado").value = soma;
}