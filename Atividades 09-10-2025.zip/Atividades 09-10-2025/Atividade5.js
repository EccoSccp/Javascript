const nota1 = parseFloat(prompt("Digite a primeira nota: "));
const nota2 = parseFloat(prompt("Digite a segunda nota: "));
const nota3 = parseFloat(prompt("Digite a terceira nota: "));

if (isNaN(nota1) || isNaN(nota2) || isNaN(nota3)) {
    alert("Digite números para as três notas.");
}
else if (media < 3) {
    alert("Você está REPROVADO!!!")
}
else if (media >= 3 && media < 6) {
    alert("Você terá fazer um exame se quiser ser aprovado.")
}
else {
    alert("APROVADO!!!")
}