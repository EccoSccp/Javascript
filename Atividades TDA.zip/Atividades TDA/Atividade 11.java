import java.util.Scanner;

public class Atividade_11 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int n1, n2;
        int soma, sub, sub1, mult;
        String divStr, div1Str, resStr, res1Str;

        System.out.print("Digite o valor do primeiro número em inteiro: ");
        n1 = sc.nextInt();

        System.out.print("Digite o valor do segundo número em inteiro: ");
        n2 = sc.nextInt();

        soma = n1 + n2;
        mult = n1 * n2;
        sub = n1 - n2;
        sub1 = n2 - n1;

        if (n2 != 0) {
            divStr = String.format("%2f", (double) n1 / n2);
            resStr = String.valueOf(n1 % n2);
        } else {
            divStr = "Erro: divisão por zero";
            resStr = "Erro: divisão por zero";
        }

        if (n1 != 0) {
            divStr = String.format("%2f", (double) n2 / n1);
            resStr = String.valueOf(n2 % n1);
        } else {
            div1Str = "Erro: divisão por zero";
            res1Str = "Erro: divisão por zero";
        }

        System.out.println("Os resultados são: ");
        System.out.println("Soma: " + soma);
        System.out.println("Multiplicação: " + mult);
        System.out.println("Subtração (n1 - n2): " + sub);
        System.out.println("Subtração (n2 - n1): " + sub1);
        System.out.println("Divisão(n1 / n2): " + divStr);
        System.out.println("Divisão (n2 / n1): " + div1Str);
        System.out.println("Resto (n1 % n2): " + resStr);
        System.out.println("Resto (n2 % n1): " + res1Str);

        sc.close();
    }
}