import java.util.Scanner;

public class Atividade_10 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        double gasto, total;

        System.out.print("Digite o valor gasto no restaurante: ");
        gasto = sc.nextDouble();

        total = gasto + (gasto * 0.10);

        System.out.println("O valor total com 10% de de garçom é: R$" + total + ".");

        sc.close();
    }
}