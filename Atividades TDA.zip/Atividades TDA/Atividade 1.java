/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.tdajava;

/**
 *
 * @author GUSTAVOPAESCANTO
 */

import java.util.Scanner;

public class TDAjava {

    public static void main(String[] args) {
        // Exercício 1
        Scanner sc  = new Scanner(System.in);
        double val1, val2 ;
        String med1, med2 ;
        System.out.println("Entre com o nome do medicamento 1: ");
        med1 = sc.nextLine();
        System.out.println("Entre com o nome do medicamento 2: ");
        med2 = sc.nextLine();
        System.out.println("Entre com o valor do medicamento 1: ");
        val1 = sc.nextDouble();
        System.out.println("Entre com o valor do medicamento 2: ");
        val2 = sc.nextDouble();
        System.out.println("O medicamento " + med1 + " custa R$" + val1 + " e o medicamento "+ med2 + " custa "+ val2);
    }
}
