import java.util.Scanner;

public class Atividade_4 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        double h, r, ab, vol;

        System.out.print("Informe o raio do cilindro: ");
        r = sc.nextDouble();

        System.out.print("Informe a altura do cilindro: ");
        h = sc.nextDouble();
        
        ab = 3.14 * (r * r);
        vol = h * ab

        System.out.print("A área da base é " + ab + " e o volume é " + vol + ".");

        sc.close();
    }
}