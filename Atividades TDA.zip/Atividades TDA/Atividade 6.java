import java.util.Scanner;

public class Atividade_6 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        double a, b, a1, b1, c1, c;

        System.out.print("Digite em metros o tamanho do lado A: ");
        a = sc.nextDouble();

        System.out.print("Digite em metros o tamanho do lado B: ");
        b = sc.nextDouble();

        a1 = a * a;
        b1 = b * b;
        c1 = a1 + b1;

        c = Math.sqrt(c1);

        System.out.print("Você terá que comprar " + c + 
        " metros para completar a cerca. ");

        sc.close();
    }
}