import java.util.Scanner;

public class Atividade_9 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int n1, n2, r1, r2

        System.out.println("Digite o primeiro valor em número inteiro: ");
        n1 = sc.nextInt();

        System.out.println("Digite o segundo valor em número inteiro:: ");
        n2 = sc.nextInt();

        if ( n2 != 0) {
            r1 = n1 % n2;
            System.out.println("O resto da divisão de " + n1 + " por" + n2 + " é: " + r1);
        } else {
            System.out.println("Erro: divisão não é permitida(divisão por zero).");
        }

        if {
            r2 = n2 % n1;
            System.out.println("O resto da divisão de " + n2 + " por" + n2 + " é: " + r2);
        } else {
            System.out.println("Erro: divisão não é permitida(divisão por zero)."
        }

        sc.close();
    }
}