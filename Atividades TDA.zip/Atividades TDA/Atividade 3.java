import java.util.Scanner;
public class Atividade_3 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        double a, b, d;

        System.out.print("Digite o valor da base do retângulo A1: ");
        a = sc.nextDouble();

        System.out.print("Digite o valor de b( altura dos retângulos A1 e A2): ");
        b = sc.nextDouble();

        System.out.print("Digite o valor de d(base do retângulo A2): ");
        d = sc.nextDouble();

        double areaA1 = a * b;
        double areaA2 = d * b;
        double areaTotal = areaA1 + areaA2;

        System.out.print("A área do retângulo A1 é " + areaA1 + " , a área do retângulo A2 é " 
        + areaA2 + " e a área total dos retângulos é " + 
        areaTotal + ".");

        sc.close();
    }
}