import java.util.Scanner;

public class Atividade_7 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        double taxa, dolar, real;

        System.out.print("Digite a taxa da conversão de Dólar para Real: ");
        taxa = sc.nextDouble();

        System.out.print("Digite um valor em Dólar: ");
        dolar = sc.nextDouble();

        real = dolar * taxa;

        System.out.print("O valor informado equivale a R$" + real + ".");

        sc.close();
    }
}