import java.util.Scanner;

public class Atividade_2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        String nome, cargo;
        int quuantidade;
        System.out.print("Digite o seu nome: ");
        nome = sc.nextLine();

        System.out.print("Digite quantos dependentes você tem: ");
        quuantidade = sc.nextInt();
        sc.nextLine();

        System.out.print("Digite o seu cargo na empresa: ");
        cargo = sc.nextLine();

        System.out.print("O seu nome é " + nome + " e você tem " + quuantidade + " dependentes e seu cargo é " + cargo + ".");

        sc.close();
    }
}