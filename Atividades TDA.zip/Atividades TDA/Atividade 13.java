import java.util.Scanner;

public class Atividade_13 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        double h, b, area;

        System.out.print("Informe a altura do triângulo: ");
        h = sc.nextDouble();

        System.out.print("Informe a base do triângulo: ");
        b = sc.nextDouble();

        area = (h * b) / 2;

        System.out.println("A área do triângulo é" + area + ".");

        sc.close();
    }
}