import java.util.Scanner;

public class Atividade_8 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int m1, m2, seg;

        System.out.print("Informe o primeiro tempo em minuto(s) inteiro(s): ");
        m1 = sc.nextInt();

        System.out.print("Informe o segundo tempo em minuto(s) inteiro(s): ");
        m2 = sc.nextInt();

        seg = (a1 * 60) + (m2 * 60);

        System.out.println("O total de segundos foi " + seg + ".");

        sc.close();
    }
}