import java.util.Scanner;

public class Atividade_12 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        double a, triplo;

        System.out.print("Informe algum número: ");
        a = sc.nextDouble();

        triplo = a * 3;

        System.out.println("O triplo do número informado é" + triplo + ".");

        sc.close();
    }
}