alert('Mensagem aleatória');
variavel = confirm('Deseja ativar as notificações? ');
variavel = prompt('Mensagem', 'Valor inicial opcional');
let x = 'Bom ';
let y = 'dia';
let z = x + y;
alert(z);
document.write(z);

// Outro exemplo
let a;
//Modo 1- Em duas etapas
let aux = prompt('Digite o valor de a:', '');
a = parseInt(aux);
//Modo 2- Em uma etapa
let b = parseInt(prompt('Digite o valor de b:', ''));
//Mostrando o cálculo
alert(a + '+' + b + '=' + (a+b));