//Exercício 1
let salario = parseFloat(prompt('Quanto você ganha de salário?', ''));
let aumento = salario * 1.25;
alert('Você ganhava R$' + salario.toFixed(2) + ' e agora com o aumento de 25%, você ganha R$' + aumento.toFixed(2));

//Exercício 2
let num = parseFloat(prompt('Digite o primeiro número: '));
let num2 = parseFloat(prompt('Digite o segundo número: '));
let num3 = parseFloat(prompt('Digite o terceiro número: '));
let num4 = parseFloat(prompt('Digite o quarto número: '));
let media = (num + num2 + num3 + num4) / 4;
alert('A média aritmética é: '+ media);

